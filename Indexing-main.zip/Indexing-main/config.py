# config.py
BING_API_KEY = 'C507D6C08ABF84479FEF3FB48B45044A'
SITE_URL = 'https://github.com/hadirealstate5/Indexing.git'
GITHUB_REPO = 'https://github.com/hadirealstate5/Indexing.git'

