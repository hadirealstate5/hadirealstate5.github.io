# config.py
BING_API_KEY = '52b172f1049a46248a53d0c0e9458960'
SITE_URL = 'https://github.com/hadirealstate5/Indexing.git'
GITHUB_REPO = 'https://github.com/hadirealstate5/Indexing.git'


